:title: Rmi Command
:description: Remove an image
:keywords: rmi, remove, image, docker, documentation

==========================
``rmi`` -- Remove an image
==========================

::

    Usage: docker rmi IMAGE [IMAGE...]

    Remove one or more images
