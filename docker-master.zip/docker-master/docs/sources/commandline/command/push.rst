:title: Push Command
:description: Push an image or a repository to the registry
:keywords: push, docker, image, repository, documentation, repo

=======================================================================
``push`` -- Push an image or a repository to the docker registry server
=======================================================================

::

    Usage: docker push NAME

    Push an image or a repository to the registry
