:title: Attach Command
:description: Attach to a running container
:keywords: attach, container, docker, documentation

===========================================
``attach`` -- Attach to a running container
===========================================

::

    Usage: docker attach CONTAINER

    Attach to a running container
