:title: Rm Command
:description: Remove a container
:keywords: remove, container, docker, documentation, rm

============================
``rm`` -- Remove a container
============================

::

    Usage: docker rm [OPTIONS] CONTAINER

    Remove one or more containers
