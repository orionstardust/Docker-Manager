:title: Stop Command
:description: Stop a running container
:keywords: stop, container, docker, documentation

====================================
``stop`` -- Stop a running container
====================================

::

    Usage: docker stop [OPTIONS] CONTAINER [CONTAINER...]

    Stop a running container

      -t=10: Number of seconds to wait for the container to stop before killing it.
