:title: Logs Command
:description: Fetch the logs of a container
:keywords: logs, container, docker, documentation

=========================================
``logs`` -- Fetch the logs of a container
=========================================

::

    Usage: docker logs [OPTIONS] CONTAINER

    Fetch the logs of a container
