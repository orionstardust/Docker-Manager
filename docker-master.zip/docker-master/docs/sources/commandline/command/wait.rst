:title: Wait Command
:description: Block until a container stops, then print its exit code.
:keywords: wait, docker, container, documentation

===================================================================
``wait`` -- Block until a container stops, then print its exit code
===================================================================

::

    Usage: docker wait [OPTIONS] NAME

    Block until a container stops, then print its exit code.
