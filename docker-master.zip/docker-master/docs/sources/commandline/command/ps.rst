:title: Ps Command
:description: List containers
:keywords: ps, docker, documentation, container

=========================
``ps`` -- List containers
=========================

::

    Usage: docker ps [OPTIONS]

    List containers

      -a=false: Show all containers. Only running containers are shown by default.
      -notrunc=false: Don't truncate output
      -q=false: Only display numeric IDs
