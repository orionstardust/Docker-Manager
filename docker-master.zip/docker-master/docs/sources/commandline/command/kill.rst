:title: Kill Command
:description: Kill a running container
:keywords: kill, container, docker, documentation

====================================
``kill`` -- Kill a running container
====================================

::

    Usage: docker kill [OPTIONS] CONTAINER [CONTAINER...]

    Kill a running container
