:title: Version Command
:description: 
:keywords: version, docker, documentation

==================================================
``version`` -- Show the docker version information
==================================================
