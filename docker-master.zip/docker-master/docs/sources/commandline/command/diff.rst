:title: Diff Command
:description: Inspect changes on a container's filesystem
:keywords: diff, docker, container, documentation

=======================================================
``diff`` -- Inspect changes on a container's filesystem
=======================================================

::

    Usage: docker diff CONTAINER [OPTIONS]

    Inspect changes on a container's filesystem
