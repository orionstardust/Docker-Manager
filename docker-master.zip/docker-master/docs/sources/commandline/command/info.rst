:title: Info Command
:description: Display system-wide information.
:keywords: info, docker, information, documentation

===========================================
``info`` -- Display system-wide information
===========================================

::

    Usage: docker info

    Display system-wide information.
