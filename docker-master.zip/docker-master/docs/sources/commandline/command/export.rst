:title: Export Command
:description: Export the contents of a filesystem as a tar archive
:keywords: export, docker, container, documentation

=================================================================
``export`` -- Stream the contents of a container as a tar archive
=================================================================

::

    Usage: docker export CONTAINER

    Export the contents of a filesystem as a tar archive
