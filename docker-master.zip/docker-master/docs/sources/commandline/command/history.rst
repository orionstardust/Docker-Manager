:title: History Command
:description: Show the history of an image
:keywords: history, docker, container, documentation

===========================================
``history`` -- Show the history of an image
===========================================

::

    Usage: docker history [OPTIONS] IMAGE

    Show the history of an image
