:title: Start Command
:description: Start a stopped container
:keywords: start, docker, container, documentation

======================================
``start`` -- Start a stopped container
======================================

::

    Usage: docker start [OPTIONS] NAME

    Start a stopped container
