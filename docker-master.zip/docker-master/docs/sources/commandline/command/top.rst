:title: Top Command
:description: Lookup the running processes of a container
:keywords: top, docker, container, documentation

=======================================================
``top`` -- Lookup the running processes of a container
=======================================================

::

    Usage: docker top CONTAINER

    Lookup the running processes of a container
