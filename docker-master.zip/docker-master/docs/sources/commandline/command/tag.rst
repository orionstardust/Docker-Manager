:title: Tag Command
:description: Tag an image into a repository
:keywords: tag, docker, image, repository, documentation, repo

=========================================
``tag`` -- Tag an image into a repository
=========================================

::

    Usage: docker tag [OPTIONS] IMAGE REPOSITORY [TAG]

    Tag an image into a repository

      -f=false: Force
