:title: Inspect Command
:description: Return low-level information on a container
:keywords: inspect, container, docker, documentation

==========================================================
``inspect`` -- Return low-level information on a container
==========================================================

::

    Usage: docker inspect [OPTIONS] CONTAINER

    Return low-level information on a container
