:title: Restart Command
:description: Restart a running container
:keywords: restart, container, docker, documentation

==========================================
``restart`` -- Restart a running container
==========================================

::

    Usage: docker restart [OPTIONS] NAME

    Restart a running container
