Buildbot configuration and setup files (except Vagrantfile located on ..)
