# Docker project infrastructure

This directory holds all information about the technical infrastructure of the docker project; servers, dns, email, and all the corresponding tools and configuration.

Obviously credentials should not be stored in this repo, but how to obtain and use them should be documented here.
