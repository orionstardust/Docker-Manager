Files used to setup the developer virtual machine
