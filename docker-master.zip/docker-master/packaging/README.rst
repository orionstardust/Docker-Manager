Docker packaging
================

This directory has one subdirectory per packaging distribution.
At minimum, each of these subdirectories should contain a
README.$DISTRIBUTION explaining how to create the native
docker package and how to install it.

